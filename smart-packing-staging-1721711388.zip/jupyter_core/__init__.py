from __future__ import annotations

from .version import __version__, version_info  # noqa: F401
